#pragma once

void register_SIGIO(int fd, void *act);
